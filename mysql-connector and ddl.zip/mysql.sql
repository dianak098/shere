########  srealtimeconvertlog  ##############

-- dg_2020ver.srealtimeconvertlog definition

CREATE TABLE `srealtimeconvertlog` (
  `log_no` int(11) NOT NULL AUTO_INCREMENT COMMENT '실시간 변환로그 고유번호',
  `convert_sdate` datetime DEFAULT NULL COMMENT '변환요청 일시',
  `convert_edate` datetime DEFAULT NULL COMMENT '변환종료 일시',
  `origin_file_nm` varchar(512) COLLATE utf8_bin DEFAULT NULL COMMENT '변환요청 파일명',
  `origin_ext` varchar(5) COLLATE utf8_bin DEFAULT NULL COMMENT '변환요청 파일 확장자',
  `request_full_url` varchar(1000) COLLATE utf8_bin DEFAULT NULL COMMENT '변환요청 파일 경로',
  `file_lastmod` varchar(45) COLLATE utf8_bin DEFAULT NULL COMMENT '파일 마지막 수정 일시',
  `file_size` int(11) DEFAULT NULL COMMENT '파일 크기',
  `tot_page` int(11) DEFAULT NULL COMMENT '전체 페이지',
  `hashvalue` varchar(128) COLLATE utf8_bin DEFAULT NULL COMMENT '파일 고유값(hash)',
  `hash_folder` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '변환파일이 저장된 경로',
  `file_key` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '요청 시 전달된 파일 고유 키값',
  `convert_yn` char(1) COLLATE utf8_bin DEFAULT 'T' COMMENT '파일 변환여부',
  `convert_file_name` varchar(512) COLLATE utf8_bin DEFAULT NULL COMMENT '변환 파일명',
  `success_yn` char(1) COLLATE utf8_bin DEFAULT 'n' COMMENT '변환 성공여부',
  `fail_log` varchar(512) COLLATE utf8_bin DEFAULT NULL COMMENT '실패 시 로그',
  PRIMARY KEY (`log_no`),
  KEY `hash_index` (`hashvalue`),
  KEY `date_index` (`convert_sdate`,`convert_edate`),
  KEY `convert_index` (`convert_yn`,`success_yn`),
  KEY `file_comp_index1` (`request_full_url`),
  KEY `file_comp_index2` (`file_lastmod`),
  KEY `file_comp_index3` (`file_size`)
) ENGINE=InnoDB AUTO_INCREMENT=19809 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



########  dg_markup_info   ###########
-- dg_2020ver.dg_markup_info definition

CREATE TABLE `dg_markup_info` (
  `document_key` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '문서 키',
  `markup_key` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '마크업 키',
  `hash` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '해시코드',
  `userid` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '사용자 ID',
  `version` int(11) NOT NULL COMMENT '마크업 버전',
  `mark_json_path` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '마크업 정보 저장경로',
  `reg_date` datetime DEFAULT NULL,
  PRIMARY KEY (`document_key`,`markup_key`,`version`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;




########   convert_sche_dtl   ##############

-- dg_2020ver.convert_sche_dtl definition

CREATE TABLE `convert_sche_dtl` (
  `sch_log_no` int(11) NOT NULL COMMENT '스케줄 변환로그 고유번호',
  `log_no` int(11) NOT NULL COMMENT '실시간 변환 로그 고유번호',
  `file_key` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '요청 시 전달된 파일 고유 키값',
  `convert_state` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '변환상태(Y:완료, F:실패, R:진행중)',
  `priority` int(1) DEFAULT 9 COMMENT '변환우선순위 1~9(1:최우선순위, 9:최후순위)',
  `request_date` datetime DEFAULT NULL COMMENT '변환요청 일시',
  `convert_msg` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '변환요청 메세지',
  `convert_info` mediumtext COLLATE utf8_bin DEFAULT NULL COMMENT '변환정보',
  `try_cnt` int(1) DEFAULT 0 COMMENT '시도행 횟수',
  KEY `convert_sche_dtl_01` (`sch_log_no`,`log_no`),
  KEY `convert_sche_dtl_02` (`log_no`),
  KEY `convert_sche_dtl_03` (`file_key`),
  KEY `convert_sche_dtl_04` (`convert_state`,`priority`),
  KEY `convert_sche_dtl_05` (`request_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='스케줄 변환 상세 정보';



#######  convert_sche_mgr   ############

-- dg_2020ver.convert_sche_mgr definition

CREATE TABLE `convert_sche_mgr` (
  `sch_log_no` int(11) NOT NULL AUTO_INCREMENT COMMENT '스케줄 변환로그 고유번호',
  `file_key` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '요청 시 전달된 파일 고유 키값',
  `convert_type` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '변환요청타입(F:파일, D:디렉토리)',
  `convert_state` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '변환요청상태(Y:완료, F:실패, R:진행중)',
  `request_full_url` varchar(1000) COLLATE utf8_bin DEFAULT NULL COMMENT '변환요청 파일 경로',
  `origin_ext` varchar(5) COLLATE utf8_bin DEFAULT NULL COMMENT '원본 파일 확장자',
  `priority` int(1) DEFAULT 9 COMMENT '변환우선순위 1~9(1:최우선순위, 9:최후순위)',
  `request_date` datetime DEFAULT NULL COMMENT '변환요청 일시',
  `convert_msg` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '변환요청 메세지',
  `try_cnt` int(1) DEFAULT 0 COMMENT '시도행 횟수',
  `add_param` mediumtext COLLATE utf8_bin DEFAULT NULL COMMENT '추가 파라미터 관리',
  PRIMARY KEY (`sch_log_no`),
  KEY `convert_sche_mgr_01` (`convert_state`,`priority`,`request_date`),
  KEY `convert_sche_mgr_02` (`file_key`),
  KEY `convert_sche_mgr_03` (`request_date`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='스케줄 변환 관리';



#######  관리자 페이지 전용  log_history  ########
-- dg_2020ver.log_history definition

CREATE TABLE `log_history` (
  `hist_log_no` int(11) NOT NULL AUTO_INCREMENT COMMENT 'loghistory 시퀀스',
  `log_no` int(11) DEFAULT NULL COMMENT '실시간 변환로그 고유번호 (srealtimeconvertlog 테이블)',
  `call_method_name` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '실행된 메서드 명',
  `origin_file_nm` varchar(2000) COLLATE utf8_bin DEFAULT NULL COMMENT '변환 원본 파일명',
  `origin_ext` varchar(2000) COLLATE utf8_bin DEFAULT NULL COMMENT '변환 원본 확장자',
  `out_type` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '변환 이미지 확장자',
  `request_full_url` varchar(2000) COLLATE utf8_bin DEFAULT NULL COMMENT '변환 호출 주소',
  `user_id` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '유저 아이디',
  `user_ip` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '유저 아이피',
  `user_os` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '유저 os정보',
  `user_browser` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '유저 브라우저 정보',
  `hashvalue` varchar(2000) COLLATE utf8_bin DEFAULT NULL COMMENT '변환 고유 값(hash)',
  `call_class_name` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '호출된 클래스명',
  `action_code` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '상태 코드(변환 결과 코드)',
  `state_msg` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '상태 메세지(변환 결과 메세지)',
  `start_date` datetime DEFAULT NULL COMMENT 'aop 시작 시간',
  `end_date` datetime DEFAULT NULL COMMENT 'aop 종료 시간',
  `in_param` mediumtext COLLATE utf8_bin DEFAULT NULL COMMENT 'in 파라미터 정보값',
  `out_param` mediumtext COLLATE utf8_bin DEFAULT NULL COMMENT 'out 파라미터 정보값',
  PRIMARY KEY (`hist_log_no`),
  KEY `LOG_HISTORY_IDX_01` (`origin_file_nm`(1024)),
  KEY `LOG_HISTORY_IDX_02` (`origin_ext`(1024)),
  KEY `LOG_HISTORY_IDX_03` (`start_date`,`call_method_name`),
  KEY `LOG_HISTORY_IDX_04` (`hashvalue`(1024)),
  KEY `LOG_HISTORY_IDX_05` (`user_id`),
  KEY `LOG_HISTORY_IDX_06` (`user_ip`)
) ENGINE=InnoDB AUTO_INCREMENT=1068 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


##########  관리자 페이지 화면권한 설정 테이블 ############
-- dg_2020ver.permissioninfo definition

CREATE TABLE `permissioninfo` (
  `user_rating_code` int(11) NOT NULL COMMENT '등급 코드',
  `rating_explain` varchar(15) NOT NULL COMMENT '등급 코드 설명',
  `viewer_permission` varchar(2000) DEFAULT NULL COMMENT '뷰어 권한 설정',
  `userID` varchar(2000) DEFAULT NULL COMMENT '유저 아이디',
  `default_code` char(2) DEFAULT NULL COMMENT '기본 등급 코드',
  PRIMARY KEY (`user_rating_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
